const targetEnv = process.env.TARGET_ENV;

const clientAppVersion = '0.3.0';

export {targetEnv, clientAppVersion};
